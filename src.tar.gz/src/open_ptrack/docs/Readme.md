### Documentation has moved to wiki - https://github.com/OpenPTrack/open_ptrack/wiki

it's nearly complete... when it is, we will export & have an offline HTML version in /doc for reference. 
